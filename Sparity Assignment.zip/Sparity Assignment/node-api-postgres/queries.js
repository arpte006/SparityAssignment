const Pool = require('pg').Pool
const pool = new Pool({
  user: 'postgres',
  host: 'localhost',
  database: 'sparity',
  password: 'postgres',
  port: 5432,
})

const getClassRoomDetails = (request, response) => {
  pool.query('SELECT * FROM Classroom ORDER BY classid ASC', (error, results) => {
    if (error) {
      throw error
    }
    response.status(200).json(results.rows)
  })
}

const getStudentId = (request, response) => {
  const id = parseInt(request.params.id)

  pool.query('SELECT * FROM Students WHERE studentid = $1', [studentid], (error, results) => {
    if (error) {
      throw error
    }
    response.status(200).json(results.rows)
  })
}

const InsertSubject = (request, response) => {
  const { subjectname } = request.body

  pool.query('INSERT INTO Subject (subjectname) VALUES ($1)', [subjectname], (error, results) => {
    if (error) {
      throw error
    }
    response.status(201).send(`User added with ID: ${result.insertId}`)
  })
}

const updateStaffName = (request, response) => {
  const facultyid = parseInt(request.params.id)
  const { facultyname } = request.body

  pool.query(
    'UPDATE Faculty SET facultyname = $1 WHERE facultyid = $2',
    [facultyname, facultyid],
    (error, results) => {
      if (error) {
        throw error
      }
      response.status(200).send(`User modified with ID: ${facultyid}`)
    }
  )
}


module.exports = {
  getClassRoomDetails,
  getStudentId,
  InsertSubject,
  updateStaffName,
}